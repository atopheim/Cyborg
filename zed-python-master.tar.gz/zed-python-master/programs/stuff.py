import cv2
import pyzed.camera as camera

def stuff():
	print(cv2.__version__)

stuff()
